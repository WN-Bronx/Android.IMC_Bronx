package org.senac.bronx_01

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import org.senac.bronx_01.org.senac.imcbronx.Imc

class MainActivity : AppCompatActivity() {

    private lateinit var peso : EditText
    private lateinit var altura : EditText
    private lateinit var generoGroup : RadioGroup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btn = findViewById<Button>(R.id.bt_calcular)
        peso = findViewById<EditText>(R.id.et_peso)
        altura = findViewById<EditText>(R.id.et_altura)
        generoGroup = findViewById<RadioGroup>(R.id.rb_genero)

        btn.setOnClickListener {
            if (validate()) {

             val genero =
                if (generoGroup.checkedRadioButtonId == R.id.rd_masculino)
                    Imc.GeneroEnum.Masculino
                else
                    Imc.GeneroEnum.Feminino

                val imc = Imc(
                    peso.text.toString().toDouble(),
                    altura.text.toString().toDouble(),
                    genero
                )

                val imcFormatado : String =
                    String.format("%.2f", imc.calcularImc()
                )

                // AlertDialog da a opção do Usuario Clicar para selecionar
            AlertDialog.Builder(this)
                .setTitle("IMC")
                .setMessage("SEU IMC é ${imcFormatado} Kg/m \n" +
                            "Classificação : ${imc.classificacaoImc()} \n" +
                            "Peso Ideal : ${String.format("%.2f",imc.pesoIdeal())}")
                .setPositiveButton("OK") {dialog, which ->  dialog.dismiss() }.show()
            /*
            Toast.makeText(
                this,
                "SEU IMC é ${imc.calcularImc()} Kg/m",
            Toast.LENGTH_LONG).show()*/
        }
    }
  }
    private fun validate() : Boolean{
        var result = true
            if (peso.getText().trim().isEmpty()){
                peso.setError("Campo é Obrigatorio")
                result = false
            }
            if (altura.getText().trim().isEmpty()){
                altura.setError("Campo é Obrigatorio")
                result = false
            }
        return result
    }
}

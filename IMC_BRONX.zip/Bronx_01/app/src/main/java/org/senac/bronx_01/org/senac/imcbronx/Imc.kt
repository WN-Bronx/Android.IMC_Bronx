package org.senac.bronx_01.org.senac.imcbronx

class Imc (val peso: Double,
           val altura: Double,
           val genero: GeneroEnum) {

    // PODE SER USADO ASSIM
    fun calcularImc(): Double {
        return peso / (altura * altura)
        // fun calcularImc() = peso / (altura * altura)
    }

    fun classificacaoImc() : String{
        val imc :Double = this.calcularImc()
        return when{
            imc < 16 -> "Baixo peso muito grave"
            imc < 17 -> "Baixo peso grave"
            imc < 18.50 -> "Baixo peso"
            imc < 25 -> "Peso Normal"
            imc < 30 -> "Sobrepeso"
            imc < 35 -> "Obesidade Grau |"
            imc < 40 -> "Obesidade Grau ||"
            else
                -> "Obesidade Grau |||"
        }
    }

    fun pesoIdeal() : Double{
        if (this.genero == GeneroEnum.Masculino){
            return (altura * 100 - 100) * 0.9
        }
            return (altura * 100 - 100) * 0.85
    }
    /* return when (this.genero){
     GeneroEnum.Masculino -> (altura * 100 - 100) * 0.9
     else -> (altura * 100 - 100) * 0.85
    }*/
    enum class GeneroEnum {
        Masculino, Feminino
    }
}